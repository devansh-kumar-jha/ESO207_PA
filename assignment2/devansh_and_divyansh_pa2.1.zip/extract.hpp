/// This function prints all the element of the
/// two-three tree in ascending order.
/// O(N) time where N is total number nodes in tree.
void Extract(twth th)
{
    th.display();
    cout<<"."<<"\n";
    return;
}
